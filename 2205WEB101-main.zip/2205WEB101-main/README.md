This is our first activity for the course, WEB101. For academic purposes only.
